package com.example.implementationofads;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {



    Button Rewardedads,Interstitialads,bannerads;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Rewardedads = findViewById(R.id.Rewardedads);
        Interstitialads = findViewById(R.id.Interstitialads);
        bannerads = findViewById(R.id.bannerads);


        bannerads.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent  intent = new Intent(MainActivity.this,BannerAdsActivity.class);
                startActivity(intent);
            }
        });
        Interstitialads.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent  intent = new Intent(MainActivity.this,InterstitialAdsActivity.class);
                startActivity(intent);
            }
        });
        Rewardedads.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent  intent = new Intent(MainActivity.this,RewardedAdsActivity.class);
                startActivity(intent);
            }
        });
    }
}